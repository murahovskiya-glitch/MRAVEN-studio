plugins {
    id("com.android.application")
}

android {
    namespace = "ru.mraven.reelsstudio"
    compileSdk = 35

    defaultConfig {
        applicationId = "ru.mraven.reelsstudio"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}

dependencies {
    implementation("androidx.webkit:webkit:1.12.1")
}
