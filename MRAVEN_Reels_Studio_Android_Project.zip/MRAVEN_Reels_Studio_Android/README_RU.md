# МРАВЕН Reels Studio — Android-проект

Это Android-оболочка WebView для исходного `reels_studio_9_16.html`.

## Что настроено
- Полноэкранное портретное приложение.
- Локальная загрузка HTML из `app/src/main/assets/index.html`.
- JavaScript и DOM Storage включены.
- Интернет разрешён для Tailwind CDN и Google Fonts, которые использует исходная страница.
- Выбор аудио, фото и видео через системный файловый диалог Android.
- Экспорт PNG/WebM/MP4 из HTML передаётся в Android и сохраняется в `Загрузки/MRAVEN Reels Studio`.

## Сборка APK
1. Установи Android Studio (актуальную стабильную версию).
2. Открой в Android Studio папку `MRAVEN_Reels_Studio_Android`.
3. Дождись Gradle Sync. При первом запуске потребуется интернет для загрузки Android Gradle Plugin и AndroidX WebKit.
4. Установи Android SDK Platform 35, если Android Studio предложит.
5. Выбери **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
6. APK появится в `app/build/outputs/apk/debug/app-debug.apk`.

## Важные замечания
- Это подготовленный исходный Android-проект, не собранный APK.
- Для экспорта видео используется WebView MediaRecorder. Поддержка конкретного контейнера (обычно WebM) зависит от версии Android System WebView.
- Встроенный HTML использует Tailwind CDN и Google Fonts, поэтому без интернета оформление может загрузиться с системными запасными шрифтами/стилями.
- Большие ролики при передаче в Android через Base64 могут потребовать значительный объём оперативной памяти.

## Автоматическая сборка в GitHub Actions
В проект добавлен workflow `.github/workflows/build-apk.yml`.
Загрузи содержимое архива в новый GitHub-репозиторий. На вкладке **Actions** запусти **Build Android APK** (или отправь push в `main`/`master`). После завершения открой запуск workflow и скачай артефакт `MRAVEN-Reels-Studio-debug-apk`.
